#!/bin/bash

python -m geektrust sample_input/input1.txt
python -m geektrust sample_input/input2.txt
python -m geektrust sample_input/input3.txt
python -m geektrust sample_input/input4.txt